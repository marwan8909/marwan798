processGoogleToken({
    "newToken": "ChAI8NGYogYQzJqkgqOQ5otmEjkAm_8Fvsq-SdWZn2PkR1HCl6-8vqgKdwpz29BkXSXaasDDGEfVMWwyH_hx0hcX6RNbEQn5I2Xc3tA",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "",
    "pucrd": ""
});