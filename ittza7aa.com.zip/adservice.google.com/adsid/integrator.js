processGoogleToken({
    "newToken": "ChAI8NGYogYQzJqkgqOQ5otmEjkAm_8Fvu6s56El5zyZYLz9e5E1t3Yi0zppR1RQeTBPn9t_MEW-bWnTg-Tv9kTJqoHXuFTkcsUGwiM",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2023-04-24-12",
    "pucrd": ""
});