var code, getIt, errorMessage;
getIt = document.getElementById("get");
errorMessage = document.getElementById("P-For-Errors");
getIt.addEventListener("click", callLinks);

function callLinks() {
    code = document.getElementById("code").value;
    switch (code) {
        case "302":
            window.location.href = "https://is.gd/BR5sTo"
            break;
        case "593":
            window.location.href = "https://is.gd/BR5sTo";
            break;
        case "504":
            window.location.href = "https://is.gd/BR5sTo";
            break;
        case "509":
            window.location.href = "https://is.gd/oT9ubq";
            break;
        case "54":
            window.location.href = "https://is.gd/mSsglQ";
            break;
        case "187":
            window.location.href = "https://is.gd/LIIaly";
            break;
        case "426":
            window.location.href = "https://is.gd/Y8TTZD";
            break;
        case "228":
            window.location.href = "https://is.gd/GIHEK1";
            break;
        case "18":
            window.location.href = "https://is.gd/IVjugr";
            break;
        case "160":
            window.location.href = "https://is.gd/X1WlNn";
            break;
        case "431":
            window.location.href = "https://is.gd/nPczSj";
            break;
        case "101":
            window.location.href = "https://is.gd/sGiEUQ";
            break;
        case "319":
            window.location.href = "https://is.gd/f6rGgf";
            break;
        case "117":
            window.location.href = "https://is.gd/J0vHRU";
            break;
        case "105":
            window.location.href = "https://is.gd/J0vHRU";
            break;
        case "793":
            window.location.href = "https://is.gd/nIEoEz";
            break;
        case "605":
            window.location.href = "https://is.gd/dmtIdN";
            break;
        case "476":
            window.location.href = "https://is.gd/xS8ZHj";
            break;
        case "":
            errorMessage.innerHTML = "تکایە ژمارەکە بنووسە";
            errorMessage.style = "text-align:center;font-size:25px;color: semibold;font-family: myFirstFont ;";
            break;
        default:
            errorMessage.innerHTML = "ئەم ژمارەیە تۆمار نەکراوە";
            errorMessage.style = "text-align:center;font-size:25px;color: semibold;font-family: myFirstFont ;";
            break;
    }
}